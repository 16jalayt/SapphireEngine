#pragma once
#include <memory>
#include <fstream>

class HIFF
{
public:
	static bool Load_HIFF(std::string filename);

protected:
};