#pragma once
#include <memory>
#include <fstream>

class CIFF
{
public:
	//CIFF();
	static bool Load_Tree(char* filename);
	//load file
protected:
	//hashlist
};

//using CIFF_ptr = std::shared_ptr<CIFF>;